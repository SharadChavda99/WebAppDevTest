import { Component, OnDestroy, OnInit } from '@angular/core';
import { IEmployee } from '../Interfaces/i-employee';
import { Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-employee-master-grid',
  templateUrl: './employee-master-grid.component.html',
  styleUrls: ['./employee-master-grid.component.css'],
})
export class EmployeeMasterGridComponent implements OnInit, OnDestroy {
  employeeData: IEmployee[] = [];
  filteredEmployeeData: IEmployee[] = [];
  searchValue: string | undefined;
  options: string[] = ['Emp Id', 'First Name', 'Email'];
  selectedOption: string = this.options[0];
  private unsubscribe = new Subject<void>();
  currentPage: number = 1;
  itemsPerPage: number = 5;
  totalItems: number = 0;

  constructor(
    private router: Router,
    private employeeService: EmployeeService
  ) {}

  search(): void {
    if (!this.searchValue) {
      this.clearFilter();
      return;
    }

    this.filteredEmployeeData = this.employeeData.filter((employee) => {
      const searchValueLower = this.searchValue?.toLowerCase();

      switch (this.selectedOption) {
        case 'Emp Id':
          return employee.refEmployeeId.toString() === searchValueLower;
        case 'First Name':
          return employee.firstName.toLowerCase() === searchValueLower;
        case 'Email':
          return employee.email.toLowerCase() === searchValueLower;
        default:
          return false;
      }
    });
  }

  clearFilter(): void {
    this.filteredEmployeeData = [...this.employeeData];
    this.searchValue = '';
    this.updatePagedEmployees();
  }

  add(): void {
    this.router.navigate(['/add']);
  }

  edit(employeeId: number): void {
    this.router.navigate(['/edit', employeeId]);
  }

  delete(employeeId: number): void {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      this.employeeService
        .deleteEmployeeData(employeeId)
        .pipe(takeUntil(this.unsubscribe))
        .subscribe({
          next: () => {
            window.alert('Data deleted successfully.');
            this.getEmployeeData();
          },
          error: (error) => console.error(error),
        });
    }
  }

  onOptionChange(event: Event): void {
    const selectedValue = (event.target as HTMLSelectElement).value;
    this.selectedOption = selectedValue;
  }

  getEmployeeData(): void {
    this.employeeService
      .getEmployeeData()
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (data) => {
          this.employeeData = data.map((item: any) => ({
            ...item,
            age: this.calculateAge(item.birthDate),
          }));
          this.filteredEmployeeData = [...this.employeeData];
          this.totalItems = this.filteredEmployeeData.length;
          this.updatePagedEmployees();
        },
        error: (error) => console.error(error),
      });
  }

  updatePagedEmployees(): void {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    this.filteredEmployeeData = this.employeeData.slice(start, end);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
    this.updatePagedEmployees();
  }

  calculateAge(birthDate: string | Date): number {
    const date =
      typeof birthDate === 'string' ? new Date(birthDate) : birthDate;

    if (!(date instanceof Date) || isNaN(date.getTime())) {
      throw new Error('Invalid date');
    }

    const today = new Date();
    let age = today.getFullYear() - date.getFullYear();
    const monthDiff = today.getMonth() - date.getMonth();

    if (
      monthDiff < 0 ||
      (monthDiff === 0 && today.getDate() < date.getDate())
    ) {
      age--;
    }

    return age;
  }

  ngOnInit(): void {
    this.getEmployeeData();
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
