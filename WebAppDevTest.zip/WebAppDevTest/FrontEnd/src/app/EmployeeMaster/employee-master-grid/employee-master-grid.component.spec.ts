import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeMasterGridComponent } from './employee-master-grid.component';

describe('EmployeeMasterGridComponent', () => {
  let component: EmployeeMasterGridComponent;
  let fixture: ComponentFixture<EmployeeMasterGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeMasterGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeMasterGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
