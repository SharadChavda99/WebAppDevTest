// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Employee, IEmployee } from '../Interfaces/i-employee';
// import { Subject, takeUntil } from 'rxjs';
// import { EmployeeService } from 'src/app/services/employee.service';
// import { IDepartment } from '../Interfaces/i-department';
// import { IDesignation } from '../Interfaces/i-designation';
// import { ActivatedRoute, Router } from '@angular/router';

// @Component({
//   selector: 'app-employee-add-edit',
//   templateUrl: './employee-add-edit.component.html',
//   styleUrls: ['./employee-add-edit.component.css'],
// })
// export class EmployeeAddEditComponent implements OnInit, OnDestroy {
//   employeeModel = new Employee();
//   departmentOptions: IDepartment[] = [];
//   designationOptions: IDesignation[] = [];
//   unsubscribe: Subject<void> = new Subject();
//   constructor(
//     private employeeService: EmployeeService,
//     private route: ActivatedRoute
//   ) {}

//   submit(): void {
//     this.employeeService
//       .saveEmployeeData(this.employeeModel)
//       .pipe(takeUntil(this.unsubscribe))
//       .subscribe(
//         (data) => {
//           console.log(data);
//         },
//         (error) => {
//           console.log(error);
//         }
//       );
//   }

//   navigateToHomePage(): void {
//     window.location.href = '/';
//   }

//   getDropdownData() {
//     this.employeeService
//       .getDropdownData()
//       .pipe(takeUntil(this.unsubscribe))
//       .subscribe(
//         (data) => {
//           console.log(data);
//           this.departmentOptions = data.departmentData;
//           this.designationOptions = data.designationData;
//         },
//         (error) => {
//           console.log(error);
//         }
//       );
//   }

//   getEmployeeById(number: number): void {
//     this.employeeService
//       .getEmployeeById(number)
//       .pipe(takeUntil(this.unsubscribe))
//       .subscribe(
//         (data) => {
//           console.log(data);
//           this.employeeModel = data;
//         },
//         (error) => {
//           console.log(error);
//         }
//       );
//   }

//   formatDateToInputFormat(date: Date): string {
//     const year = date.getFullYear();
//     const month = String(date.getMonth() + 1).padStart(2, '0');
//     const day = String(date.getDate()).padStart(2, '0');
//     return `${year}-${month}-${day}`;
//   }

//   ngOnInit(): void {
//     this.getDropdownData();
//     this.route.paramMap.subscribe((params) => {
//       const empId = Number(params.get('empId'));
//       if (empId) {
//         this.getEmployeeById(empId);
//       }
//     });
//   }

//   ngOnDestroy(): void {
//     this.unsubscribe.next();
//     this.unsubscribe.complete();
//   }
// }
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Employee, IEmployee } from '../Interfaces/i-employee';
import { Subject, takeUntil } from 'rxjs';
import { EmployeeService } from 'src/app/services/employee.service';
import { IDepartment } from '../Interfaces/i-department';
import { IDesignation } from '../Interfaces/i-designation';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-employee-add-edit',
  templateUrl: './employee-add-edit.component.html',
  styleUrls: ['./employee-add-edit.component.css'],
})
export class EmployeeAddEditComponent implements OnInit, OnDestroy {
  employeeModel: IEmployee = new Employee();
  departmentOptions: IDepartment[] = [];
  designationOptions: IDesignation[] = [];
  private unsubscribe = new Subject<void>();

  constructor(
    private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  submit(): void {
    this.employeeService
      .saveEmployeeData(this.employeeModel)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (data) => {},
        error: (error) => {
          console.error('Error saving employee data:', error);
        },
        complete: () => {
          this.router.navigate(['/']);
        },
      });
  }

  loadDropdownData(): void {
    this.employeeService
      .getDropdownData()
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (data) => {
          this.departmentOptions = data.departmentData;
          this.designationOptions = data.designationData;
        },
        error: (error) => {
          console.error('Error loading dropdown data:', error);
        },
      });
  }

  loadEmployeeById(empId: number): void {
    this.employeeService
      .getEmployeeById(empId)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe({
        next: (data) => {
          this.employeeModel = data;
        },
        error: (error) => {
          console.error('Error loading employee data:', error);
        },
      });
  }

  onDateInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    const dateValue = this.parseDate(input.value);
    this.employeeModel.birthDate = dateValue;
  }

  parseDate(dateString: string): Date {
    return new Date(dateString);
  }

  navigateToHomePage(): void {
    this.router.navigate(['/']);
  }

  ngOnInit(): void {
    this.loadDropdownData();
    this.route.paramMap.subscribe((params) => {
      const empId = Number(params.get('empId'));
      if (empId) {
        this.loadEmployeeById(empId);
      }
    });
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
