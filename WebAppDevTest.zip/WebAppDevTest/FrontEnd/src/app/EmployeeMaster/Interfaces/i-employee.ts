export interface IEmployee {
  refEmployeeId: number;
  employeeTag: string;
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  birthDate?: Date;
  age?: number;
  designation: string;
  departmentId: number;
  designationId: number;
  addedBy: string;
  addedOn?: Date;
  lastEditedBy: string;
  editedOn?: Date;
}

export class Employee implements IEmployee {
  refEmployeeId: number;
  employeeTag: string;
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  birthDate?: Date;
  age?: number;
  designation: string;
  departmentId: number;
  designationId: number;
  addedBy: string;
  addedOn?: Date;
  lastEditedBy: string;
  editedOn?: Date;

  constructor() {
    this.refEmployeeId = 0; // Default value for empId
    this.employeeTag = ''; // Default value for employeeTag
    this.firstName = ''; // Default value for firstName
    this.lastName = ''; // Default value for lastName
    this.email = ''; // Default value for email
    this.department = ''; // Default value for department
    this.birthDate = new Date(); // Default value for birthDate (optional)
    this.age = undefined; // Default value for age (optional)
    this.designation = ''; // Default value for designation
    this.departmentId = 0; // Default value for departmentId
    this.designationId = 0; // Default value for designationId
    this.addedBy = 'admin';
    this.lastEditedBy = 'admin';
    this.addedOn = new Date();
    this.editedOn = new Date();
  }
}
