export interface IDesignation {
  refDesignationId: number;
  designationName: string;
}
