export interface IDepartment {
  refDepartmentId: number;
  departmentName: string;
}
