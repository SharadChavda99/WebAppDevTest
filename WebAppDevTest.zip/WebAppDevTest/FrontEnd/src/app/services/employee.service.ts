import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { IEmployee } from '../EmployeeMaster/Interfaces/i-employee';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  private readonly baseUrl = 'http://localhost:5080/Employee';

  private getEmployeeDataUrl = `${this.baseUrl}/GetAllEmployees`;
  private getEmployeeByIdUrl = `${this.baseUrl}/GetEmployeeById`;
  private saveEmployeeDataUrl = `${this.baseUrl}/SaveEmployee`;
  private getDropdownDataUrl = `${this.baseUrl}/GetAllDropdownData`;
  private deleteEmployeeDataUrl = `${this.baseUrl}/DeleteEmployee`;

  constructor(private http: HttpClient) {}

  getEmployeeData(): Observable<IEmployee[]> {
    return this.http.get<IEmployee[]>(this.getEmployeeDataUrl);
  }

  getEmployeeById(empId: number): Observable<IEmployee> {
    const url = `${this.getEmployeeByIdUrl}/${empId}`;
    return this.http.get<IEmployee>(url);
  }

  saveEmployeeData(emp: IEmployee): Observable<void> {
    return this.http.post<void>(this.saveEmployeeDataUrl, emp);
  }

  getDropdownData(): Observable<any> {
    return this.http.get<any>(this.getDropdownDataUrl);
  }

  deleteEmployeeData(empId: number): Observable<any> {
    const url = `${this.deleteEmployeeDataUrl}/${empId}`;
    return this.http.delete<any>(url);
  }
}
