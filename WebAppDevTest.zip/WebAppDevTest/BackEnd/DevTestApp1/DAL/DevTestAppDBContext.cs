﻿using DevTestApp1.Model;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using System;

namespace DevTestApp1.DAL
{
    public class DevTestAppDBContext : DbContext
    {
        public DevTestAppDBContext(DbContextOptions<DevTestAppDBContext> options) : base(options)
        {

        }
        public DevTestAppDBContext()
        {
            
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = WebAppDevTest; Integrated Security = True; Encrypt=false;");
        }
        public DbSet<RefDepartment> RefDepartment { get; set; }
        public DbSet<RefDesignation> RefDesignation { get; set; }
        public DbSet<RefEmployee> RefEmployee { get; set; }
    }
}
