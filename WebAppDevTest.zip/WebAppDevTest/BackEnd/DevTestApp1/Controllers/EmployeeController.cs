using DevTestApp1.Business.Interface;
using DevTestApp1.Model.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DevTestApp1.Controllers
{
    [ApiController]
    [Route("Employee")]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeManager _employeeManager;

        public EmployeeController(IEmployeeManager employeeManager)
        {
            _employeeManager = employeeManager;
        }

        [HttpGet("GetAllEmployees")]
        public IActionResult GetAllEmployees()
        {
            try
            {
                var employees = _employeeManager.GetAllEmployees();
                return Ok(employees);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

        [HttpGet("GetAllDropdownData")]
        public IActionResult GetAllDropdownData()
        {
            try
            {
                var designationData = _employeeManager.GetAllDesignation();
                var departmentData = _employeeManager.GetAllDepartment();
                return Ok(new { designationData, departmentData });
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

        [HttpPost("SaveEmployee")]
        public IActionResult SaveEmployee([FromBody] RefEmployeeDto empDto)
        {
            if (empDto == null)
            {
                return BadRequest("Employee data cannot be null.");
            }

            try
            {
                _employeeManager.SaveEmployee(empDto);
                return Ok("Saved successfully.");
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

        [HttpGet("GetEmployeeById/{empId}")]
        public IActionResult GetEmployeeById(int empId)
        {
            try
            {
                var employee = _employeeManager.GetEmployeeById(empId);
                if (employee == null)
                {
                    return NotFound($"Employee with ID {empId} not found.");
                }

                return Ok(employee);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

        [HttpDelete("DeleteEmployee/{empId}")]
        public IActionResult DeleteEmployee(int empId)
        {
            try
            {
                _employeeManager.DeleteEmployee(empId);
                return NoContent();
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }
    }
}
