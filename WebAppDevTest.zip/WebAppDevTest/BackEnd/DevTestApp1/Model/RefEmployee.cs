﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DevTestApp1.Model
{
    public class RefEmployee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int RefEmployeeId { get; set; }

        [StringLength(50)]
        public string EmployeeTag { get; set; }

        [Required]
        [StringLength(50)]
        public string FirstName { get; set; }

        [StringLength(50)]
        public string LastName { get; set; }

        [StringLength(100)]
        public string Email { get; set; }

        public int? DepartmentId { get; set; }
        public int? DesignationId { get; set; }

        public DateTime? BirthDate { get; set; }

        [StringLength(50)]
        public string AddedBy { get; set; }

        public DateTime? AddedOn { get; set; }

        [StringLength(50)]
        public string LastEditedBy { get; set; }

        public DateTime? EditedOn { get; set; }

        // Navigation properties
        [ForeignKey("DepartmentId")]
        public virtual RefDepartment Department { get; set; }

        [ForeignKey("DesignationId")]
        public virtual RefDesignation Designation { get; set; }
    }
}
