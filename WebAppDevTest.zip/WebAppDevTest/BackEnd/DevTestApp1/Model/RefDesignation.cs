﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
namespace DevTestApp1.Model
{
    public class RefDesignation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int RefDesignationId { get; set; }

        [StringLength(50)]
        public string DesignationName { get; set; }

        [StringLength(50)]
        public string Code { get; set; }
    }
}
