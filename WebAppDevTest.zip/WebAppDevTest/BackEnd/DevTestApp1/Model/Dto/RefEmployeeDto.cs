﻿using System.ComponentModel.DataAnnotations;

namespace DevTestApp1.Model.Dto
{
    public class RefEmployeeDto
    {
        public int RefEmployeeId { get; set; }
        public string EmployeeTag { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int? DepartmentId { get; set; }
        public int? DesignationId { get; set; }
        public string Department { get; set; }
        public string Designation { get; set; }
        public DateTime? BirthDate { get; set; }
        public string AddedBy { get; set; }
        public DateTime? AddedOn { get; set; }
        public string LastEditedBy { get; set; }
        public DateTime? EditedOn { get; set; }
    }
}
