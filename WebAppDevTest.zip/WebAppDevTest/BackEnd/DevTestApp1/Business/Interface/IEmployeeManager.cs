﻿using DevTestApp1.Model;
using DevTestApp1.Model.Dto;
using Microsoft.AspNetCore.Mvc;

namespace DevTestApp1.Business.Interface
{
    public interface IEmployeeManager
    {
        List<RefEmployeeDto> GetAllEmployees();
        List<RefDepartment> GetAllDepartment();
        List<RefDesignation> GetAllDesignation();
        void SaveEmployee(RefEmployeeDto empDto);
        void DeleteEmployee(int empId);
        RefEmployeeDto GetEmployeeById(int empId);
    }
}
