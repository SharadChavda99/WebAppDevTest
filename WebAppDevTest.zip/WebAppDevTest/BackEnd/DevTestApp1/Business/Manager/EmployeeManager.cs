﻿using DevTestApp1.Business.Interface;
using DevTestApp1.DAL;
using DevTestApp1.Model;
using DevTestApp1.Model.Dto;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace DevTestApp1.Business.Manager
{
    public class EmployeeManager : IEmployeeManager
    {
        private readonly DevTestAppDBContext _context;
        public EmployeeManager()
        {
            _context = new DevTestAppDBContext();
        }
        public List<RefEmployeeDto> GetAllEmployees()
        {
            return _context.RefEmployee
                .Include(e => e.Department)
                .Include(e => e.Designation)
                .Select(e => new RefEmployeeDto
                {
                    RefEmployeeId = e.RefEmployeeId,
                    EmployeeTag = e.EmployeeTag,
                    FirstName = e.FirstName,
                    LastName = e.LastName,
                    Email = e.Email,
                    Department = e.Department.DepartmentName,
                    Designation = e.Designation.DesignationName,
                    BirthDate = e.BirthDate,
                    AddedBy = e.AddedBy,
                    AddedOn = e.AddedOn,
                    LastEditedBy = e.LastEditedBy,
                    EditedOn = e.EditedOn
                })
                .ToList();
        }

        public void SaveEmployee(RefEmployeeDto dto)
        {
            if (dto == null)
                throw new ArgumentNullException(nameof(dto));

            var emp = new RefEmployee
            {
                RefEmployeeId = dto.RefEmployeeId,
                EmployeeTag = dto.EmployeeTag,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                DepartmentId = dto.DepartmentId,
                DesignationId = dto.DesignationId,
                BirthDate = dto.BirthDate,
                AddedBy = dto.AddedBy,
                AddedOn = dto.AddedOn,
                LastEditedBy = dto.LastEditedBy,
                EditedOn = dto.EditedOn,
            };

            if (dto.RefEmployeeId == 0)
                _context.RefEmployee.Add(emp);
            else
                _context.RefEmployee.Update(emp);

            _context.SaveChanges();
        }

        public List<RefDepartment> GetAllDepartment()
        {
            return _context.RefDepartment.ToList();
        }

        public List<RefDesignation> GetAllDesignation()
        {
            return _context.RefDesignation.ToList();
        }

        public RefEmployeeDto GetEmployeeById(int empId)
        {
            if (empId <= 0)
                throw new ApplicationException("Invalid employee ID.");

            var employee = _context.RefEmployee
                .Include(e => e.Department)
                .Include(e => e.Designation)
                .Where(e => e.RefEmployeeId == empId)
                .Select(e => new RefEmployeeDto
                {
                    RefEmployeeId = e.RefEmployeeId,
                    EmployeeTag = e.EmployeeTag,
                    FirstName = e.FirstName,
                    LastName = e.LastName,
                    Email = e.Email,
                    DepartmentId = e.Department.RefDepartmentId,
                    Department = e.Department.DepartmentName,
                    DesignationId = e.Designation.RefDesignationId,
                    Designation = e.Designation.DesignationName,
                    BirthDate = e.BirthDate,
                    AddedBy = e.AddedBy,
                    AddedOn = e.AddedOn,
                    LastEditedBy = e.LastEditedBy,
                    EditedOn = e.EditedOn
                })
                .FirstOrDefault();

            if (employee == null)
                throw new ApplicationException($"Employee with ID {empId} not found.");

            return employee;
        }

        public void DeleteEmployee(int empId)
        {
            if (empId <= 0)
                throw new ApplicationException("Invalid employee ID.");

            var emp = _context.RefEmployee.Find(empId);
            if (emp == null)
                throw new ApplicationException("Employee not found for deletion.");

            _context.RefEmployee.Remove(emp);
            _context.SaveChanges();
        }
    }
}