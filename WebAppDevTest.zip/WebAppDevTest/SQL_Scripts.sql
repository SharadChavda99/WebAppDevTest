--Creation of DB STARTS
GO
CREATE DATABASE [WebAppDevTest]
GO
--Creation of DB ENDS

--Creation of Tables STARTS
GO
CREATE TABLE dbo.RefDepartment
(
	RefDepartmentId INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	DepartmentName VARCHAR(50) COLLATE DATABASE_DEFAULT,
	Code VARCHAR(50) COLLATE DATABASE_DEFAULT 
)
GO
CREATE TABLE dbo.RefDesignation
(
	RefDesignationId INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	DesignationName VARCHAR(50) COLLATE DATABASE_DEFAULT,
	Code VARCHAR(50) COLLATE DATABASE_DEFAULT 
)
GO
CREATE TABLE dbo.RefEmployee
(
	RefEmployeeId INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	EmployeeTag VARCHAR(50) COLLATE DATABASE_DEFAULT,
	FirstName VARCHAR(50) COLLATE DATABASE_DEFAULT NOT NULL,
	LastName VARCHAR(50) COLLATE DATABASE_DEFAULT,
	Email VARCHAR(100) COLLATE DATABASE_DEFAULT,
	DepartmentId INT,
	BirthDate DATETIME,
	DesignationId INT,
	AddedBy VARCHAR(50) COLLATE DATABASE_DEFAULT,
	AddedOn DATETIME,
	LastEditedBy VARCHAR(50) COLLATE DATABASE_DEFAULT,
	EditedOn DATETIME
)
ALTER TABLE dbo.RefEmployee ADD CONSTRAINT FK_RefEmployee_DepartmentId FOREIGN KEY (DepartmentId) REFERENCES dbo.RefDepartment(RefDepartmentId)
ALTER TABLE dbo.RefEmployee ADD CONSTRAINT FK_RefEmployee_DesignationId FOREIGN KEY (DesignationId) REFERENCES dbo.RefDesignation(RefDesignationId)
GO
--Creation of Tables ENDS

--Data Ingestion STARTS
GO
INSERT INTO dbo.RefDepartment (DepartmentName, Code)
VALUES 
('Human Resources', 'HR001'),
('Finance', 'FIN001'),
('Information Technology', 'IT001'),
('Marketing', 'MKT001'),
('Sales', 'SLS001');
GO
INSERT INTO dbo.RefDesignation (DesignationName, Code)
VALUES 
('Software Engineer', 'SE001'),
('Senior Software Engineer', 'SSE002'),
('Project Manager', 'PM003'),
('Technical Lead', 'TL004'),
('Business Analyst', 'BA005');
GO
INSERT INTO dbo.RefEmployee 
(
    EmployeeTag, 
    FirstName, 
    LastName, 
    Email, 
    DepartmentId, 
    BirthDate, 
    DesignationId, 
    AddedBy, 
    AddedOn, 
    LastEditedBy, 
    EditedOn
)
VALUES 
('EMP001', 'John', 'Doe', 'john.doe@example.com', 1, '1985-04-12', 1, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP002', 'Jane', 'Smith', 'jane.smith@example.com', 2, '1990-08-21', 2, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP003', 'Robert', 'Brown', 'robert.brown@example.com', 3, '1987-12-05', 3, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP004', 'Emily', 'Davis', 'emily.davis@example.com', 4, '1992-06-17', 4, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP005', 'Michael', 'Wilson', 'michael.wilson@example.com', 5, '1989-11-30', 5, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP006', 'Sarah', 'Taylor', 'sarah.taylor@example.com', 1, '1983-03-22', 2, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP007', 'David', 'Johnson', 'david.johnson@example.com', 2, '1978-07-15', 3, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP008', 'Laura', 'Martinez', 'laura.martinez@example.com', 3, '1995-10-29', 4, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP009', 'James', 'Anderson', 'james.anderson@example.com', 4, '1991-01-08', 1, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP010', 'Sophia', 'Thomas', 'sophia.thomas@example.com', 5, '1988-09-19', 5, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP011', 'Daniel', 'Lee', 'daniel.lee@example.com', 1, '1986-05-04', 4, 'admin', GETDATE(), 'admin', GETDATE()),
('EMP012', 'Olivia', 'Harris', 'olivia.harris@example.com', 2, '1993-02-11', 3, 'admin', GETDATE(), 'admin', GETDATE());
GO

